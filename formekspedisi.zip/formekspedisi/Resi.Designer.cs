﻿namespace formekspedisi
{
    partial class Resi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.data_pengirim = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.data_penerima = new System.Windows.Forms.Label();
            this.alamat_penerima = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.b_lain = new System.Windows.Forms.Label();
            this.b_asuransi = new System.Windows.Forms.Label();
            this.ongkir = new System.Windows.Forms.Label();
            this.lain = new System.Windows.Forms.Label();
            this.asuransi = new System.Windows.Forms.Label();
            this.b_kirim = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.total = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.metode_pembayaran = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.jenis_pengiriman = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.berat_barang = new System.Windows.Forms.Label();
            this.deskripsi = new System.Windows.Forms.Label();
            this.resi_id = new System.Windows.Forms.Label();
            this.barcode_img = new System.Windows.Forms.PictureBox();
            this.qrcode_img = new System.Windows.Forms.PictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txt_deskripsi = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barcode_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrcode_img)).BeginInit();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(164, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "Pengirim :";
            // 
            // data_pengirim
            // 
            this.data_pengirim.AutoSize = true;
            this.data_pengirim.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.data_pengirim.ForeColor = System.Drawing.Color.Gainsboro;
            this.data_pengirim.Location = new System.Drawing.Point(250, 148);
            this.data_pengirim.Name = "data_pengirim";
            this.data_pengirim.Size = new System.Drawing.Size(0, 21);
            this.data_pengirim.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(165, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(183, 21);
            this.label2.TabIndex = 5;
            this.label2.Text = "SURABAYA, JAWA TIMUR";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(164, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "Penerima :";
            // 
            // data_penerima
            // 
            this.data_penerima.AutoSize = true;
            this.data_penerima.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.data_penerima.ForeColor = System.Drawing.Color.Gainsboro;
            this.data_penerima.Location = new System.Drawing.Point(250, 226);
            this.data_penerima.Name = "data_penerima";
            this.data_penerima.Size = new System.Drawing.Size(0, 21);
            this.data_penerima.TabIndex = 6;
            // 
            // alamat_penerima
            // 
            this.alamat_penerima.AutoSize = true;
            this.alamat_penerima.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alamat_penerima.ForeColor = System.Drawing.Color.Gainsboro;
            this.alamat_penerima.Location = new System.Drawing.Point(166, 247);
            this.alamat_penerima.Name = "alamat_penerima";
            this.alamat_penerima.Size = new System.Drawing.Size(0, 21);
            this.alamat_penerima.TabIndex = 7;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.b_lain);
            this.panel2.Controls.Add(this.b_asuransi);
            this.panel2.Controls.Add(this.ongkir);
            this.panel2.Controls.Add(this.lain);
            this.panel2.Controls.Add(this.asuransi);
            this.panel2.Controls.Add(this.b_kirim);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Location = new System.Drawing.Point(168, 314);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(206, 127);
            this.panel2.TabIndex = 8;
            // 
            // b_lain
            // 
            this.b_lain.AutoSize = true;
            this.b_lain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_lain.ForeColor = System.Drawing.Color.Gainsboro;
            this.b_lain.Location = new System.Drawing.Point(68, 102);
            this.b_lain.Name = "b_lain";
            this.b_lain.Size = new System.Drawing.Size(0, 20);
            this.b_lain.TabIndex = 10;
            // 
            // b_asuransi
            // 
            this.b_asuransi.AutoSize = true;
            this.b_asuransi.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_asuransi.ForeColor = System.Drawing.Color.Gainsboro;
            this.b_asuransi.Location = new System.Drawing.Point(74, 74);
            this.b_asuransi.Name = "b_asuransi";
            this.b_asuransi.Size = new System.Drawing.Size(0, 20);
            this.b_asuransi.TabIndex = 10;
            // 
            // ongkir
            // 
            this.ongkir.AutoSize = true;
            this.ongkir.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ongkir.ForeColor = System.Drawing.Color.Gainsboro;
            this.ongkir.Location = new System.Drawing.Point(66, 51);
            this.ongkir.Name = "ongkir";
            this.ongkir.Size = new System.Drawing.Size(0, 20);
            this.ongkir.TabIndex = 10;
            // 
            // lain
            // 
            this.lain.AutoSize = true;
            this.lain.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lain.ForeColor = System.Drawing.Color.Gainsboro;
            this.lain.Location = new System.Drawing.Point(3, 101);
            this.lain.Name = "lain";
            this.lain.Size = new System.Drawing.Size(63, 17);
            this.lain.TabIndex = 9;
            this.lain.Text = "Lain-lain :";
            // 
            // asuransi
            // 
            this.asuransi.AutoSize = true;
            this.asuransi.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.asuransi.ForeColor = System.Drawing.Color.Gainsboro;
            this.asuransi.Location = new System.Drawing.Point(3, 75);
            this.asuransi.Name = "asuransi";
            this.asuransi.Size = new System.Drawing.Size(64, 17);
            this.asuransi.TabIndex = 9;
            this.asuransi.Text = "Asuransi :";
            // 
            // b_kirim
            // 
            this.b_kirim.AutoSize = true;
            this.b_kirim.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_kirim.ForeColor = System.Drawing.Color.Gainsboro;
            this.b_kirim.Location = new System.Drawing.Point(3, 50);
            this.b_kirim.Name = "b_kirim";
            this.b_kirim.Size = new System.Drawing.Size(59, 17);
            this.b_kirim.TabIndex = 9;
            this.b_kirim.Text = "B. Kirim :";
            // 
            // panel8
            // 
            this.panel8.Location = new System.Drawing.Point(234, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(175, 33);
            this.panel8.TabIndex = 8;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.total);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.panel11);
            this.panel6.Location = new System.Drawing.Point(368, 314);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(231, 127);
            this.panel6.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(54, 103);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Sudah Termasuk Pajak";
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.BackColor = System.Drawing.Color.Transparent;
            this.total.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(138)))), ((int)(((byte)(114)))));
            this.total.Location = new System.Drawing.Point(64, 75);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(0, 21);
            this.total.TabIndex = 9;
            this.total.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(62, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "TOTAL BIAYA";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.metode_pembayaran);
            this.panel11.Location = new System.Drawing.Point(-1, -1);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(231, 43);
            this.panel11.TabIndex = 8;
            // 
            // metode_pembayaran
            // 
            this.metode_pembayaran.AutoSize = true;
            this.metode_pembayaran.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metode_pembayaran.ForeColor = System.Drawing.Color.Gainsboro;
            this.metode_pembayaran.Location = new System.Drawing.Point(80, 9);
            this.metode_pembayaran.Name = "metode_pembayaran";
            this.metode_pembayaran.Size = new System.Drawing.Size(77, 21);
            this.metode_pembayaran.TabIndex = 0;
            this.metode_pembayaran.Text = "Non Cod";
            this.metode_pembayaran.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.jenis_pengiriman);
            this.panel7.Location = new System.Drawing.Point(168, 314);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(206, 43);
            this.panel7.TabIndex = 8;
            // 
            // jenis_pengiriman
            // 
            this.jenis_pengiriman.AutoSize = true;
            this.jenis_pengiriman.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jenis_pengiriman.ForeColor = System.Drawing.Color.Gainsboro;
            this.jenis_pengiriman.Location = new System.Drawing.Point(136, 11);
            this.jenis_pengiriman.Name = "jenis_pengiriman";
            this.jenis_pengiriman.Size = new System.Drawing.Size(0, 21);
            this.jenis_pengiriman.TabIndex = 0;
            this.jenis_pengiriman.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.berat_barang);
            this.panel9.Location = new System.Drawing.Point(168, 314);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(105, 43);
            this.panel9.TabIndex = 8;
            // 
            // berat_barang
            // 
            this.berat_barang.AutoSize = true;
            this.berat_barang.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.berat_barang.ForeColor = System.Drawing.Color.Gainsboro;
            this.berat_barang.Location = new System.Drawing.Point(26, 9);
            this.berat_barang.Name = "berat_barang";
            this.berat_barang.Size = new System.Drawing.Size(0, 21);
            this.berat_barang.TabIndex = 0;
            // 
            // deskripsi
            // 
            this.deskripsi.AutoSize = true;
            this.deskripsi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deskripsi.ForeColor = System.Drawing.Color.Gainsboro;
            this.deskripsi.Location = new System.Drawing.Point(166, 280);
            this.deskripsi.Name = "deskripsi";
            this.deskripsi.Size = new System.Drawing.Size(81, 21);
            this.deskripsi.TabIndex = 7;
            this.deskripsi.Text = "Deskripsi :";
            // 
            // resi_id
            // 
            this.resi_id.AutoSize = true;
            this.resi_id.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resi_id.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(138)))), ((int)(((byte)(114)))));
            this.resi_id.Location = new System.Drawing.Point(373, 121);
            this.resi_id.Name = "resi_id";
            this.resi_id.Size = new System.Drawing.Size(141, 25);
            this.resi_id.TabIndex = 11;
            this.resi_id.Text = "JS12193801799";
            // 
            // barcode_img
            // 
            this.barcode_img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.barcode_img.Location = new System.Drawing.Point(169, 74);
            this.barcode_img.Name = "barcode_img";
            this.barcode_img.Size = new System.Drawing.Size(558, 44);
            this.barcode_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.barcode_img.TabIndex = 12;
            this.barcode_img.TabStop = false;
            // 
            // qrcode_img
            // 
            this.qrcode_img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.qrcode_img.Location = new System.Drawing.Point(3, 2);
            this.qrcode_img.Margin = new System.Windows.Forms.Padding(1);
            this.qrcode_img.Name = "qrcode_img";
            this.qrcode_img.Size = new System.Drawing.Size(120, 120);
            this.qrcode_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.qrcode_img.TabIndex = 1;
            this.qrcode_img.TabStop = false;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(138)))), ((int)(((byte)(114)))));
            this.panel13.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel13.Location = new System.Drawing.Point(167, 144);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(558, 1);
            this.panel13.TabIndex = 13;
            // 
            // txt_deskripsi
            // 
            this.txt_deskripsi.AutoSize = true;
            this.txt_deskripsi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_deskripsi.ForeColor = System.Drawing.Color.Gainsboro;
            this.txt_deskripsi.Location = new System.Drawing.Point(253, 280);
            this.txt_deskripsi.Name = "txt_deskripsi";
            this.txt_deskripsi.Size = new System.Drawing.Size(0, 21);
            this.txt_deskripsi.TabIndex = 7;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.qrcode_img);
            this.panel10.Location = new System.Drawing.Point(598, 314);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(127, 127);
            this.panel10.TabIndex = 14;
            // 
            // Resi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(2)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(897, 525);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.barcode_img);
            this.Controls.Add(this.resi_id);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txt_deskripsi);
            this.Controls.Add(this.deskripsi);
            this.Controls.Add(this.alamat_penerima);
            this.Controls.Add(this.data_penerima);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.data_pengirim);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "Resi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Resi";
            this.Load += new System.EventHandler(this.Resi_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barcode_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrcode_img)).EndInit();
            this.panel10.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label data_pengirim;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label data_penerima;
        private System.Windows.Forms.Label alamat_penerima;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label metode_pembayaran;
        private System.Windows.Forms.Label jenis_pengiriman;
        private System.Windows.Forms.Label berat_barang;
        private System.Windows.Forms.Label lain;
        private System.Windows.Forms.Label asuransi;
        private System.Windows.Forms.Label b_kirim;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label ongkir;
        private System.Windows.Forms.Label b_lain;
        private System.Windows.Forms.Label b_asuransi;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label deskripsi;
        private System.Windows.Forms.Label resi_id;
        private System.Windows.Forms.PictureBox qrcode_img;
        private System.Windows.Forms.PictureBox barcode_img;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label txt_deskripsi;
        private System.Windows.Forms.Panel panel10;
    }
}